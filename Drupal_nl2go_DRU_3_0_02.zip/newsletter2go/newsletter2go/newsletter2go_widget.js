jQuery(document).ready(function () {
    jQuery('body').html(jQuery('#n2goResponseArea'));
    window.parent.n2goPreviewRendered();
});